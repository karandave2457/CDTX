export interface AvailabilitySlot {
  date: string;
  times: string[];
}

export interface Physician {
  id: string;
  name: string;
  specialty: string;
  clinicName: string;
  city: string;
  province: string;
  phone: string;
  email: string;
  rating: number;
  yearsExperience: number;
  bio: string;
  bookingUrl: string;
  availability: AvailabilitySlot[];
}

export interface PhysicianResponse {
  physicians: Physician[];
}

export interface Condition {
  id: string;
  name: string;
  icon: string; // Component name or path
}