import { GoogleGenAI, Type, Schema } from "@google/genai";
import { PhysicianResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const physicianSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    physicians: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          name: { type: Type.STRING },
          specialty: { type: Type.STRING },
          clinicName: { type: Type.STRING },
          city: { type: Type.STRING },
          province: { type: Type.STRING },
          phone: { type: Type.STRING },
          email: { type: Type.STRING },
          rating: { type: Type.NUMBER },
          yearsExperience: { type: Type.NUMBER },
          bio: { type: Type.STRING },
          bookingUrl: { type: Type.STRING },
          availability: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                date: { type: Type.STRING, description: "YYYY-MM-DD format" },
                times: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["date", "times"]
            }
          }
        },
        required: ["id", "name", "specialty", "clinicName", "city", "province", "phone", "rating", "availability", "bio", "bookingUrl"]
      }
    }
  },
  required: ["physicians"]
};

export const fetchTopPhysicians = async (condition: string): Promise<PhysicianResponse> => {
  // Calculate date range: Today to 6 months from now
  const today = new Date();
  const sixMonthsLater = new Date(today);
  sixMonthsLater.setMonth(today.getMonth() + 6);

  // Format dates as YYYY-MM-DD
  const formatDate = (date: Date) => date.toISOString().split('T')[0];
  const startDateStr = formatDate(today);
  const endDateStr = formatDate(sixMonthsLater);

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `
        Generate a realistic JSON list of the top 10 medical specialists in Canada who treat "${condition}".
        
        The data should include:
        1. Real or realistically generated physician names and clinics appropriate for Canadian cities (Toronto, Vancouver, Montreal, Calgary, etc.).
        2. A realistic rating between 4.0 and 5.0.
        3. A brief professional bio.
        4. Contact info (use placeholders for phone/email if real ones aren't available, but format them correctly).
        5. "bookingUrl": A realistic URL for booking an appointment (e.g., "https://www.ratemds.com/..." or a clinic website).
        6. "availability": Generate 3-5 distinct dates strictly between today (${startDateStr}) and 6 months from now (${endDateStr}). 
           - Ensure the dates are within this specific range.
           - For each date, list 2-4 specific time slots (e.g., "10:00 AM", "2:30 PM").
        
        Ensure the "specialty" matches the medical condition provided.
        Identify the province correctly for the city.
      `,
      config: {
        responseMimeType: 'application/json',
        responseSchema: physicianSchema,
        thinkingConfig: { thinkingBudget: 0 } // Disable thinking for faster JSON generation
      }
    });

    const text = response.text;
    if (!text) {
        throw new Error("No data returned from AI");
    }
    
    return JSON.parse(text) as PhysicianResponse;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};