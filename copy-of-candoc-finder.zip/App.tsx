import React, { useState } from 'react';
import { Header } from './components/Header';
import { ConditionSearch } from './components/ConditionSearch';
import { PhysicianList } from './components/PhysicianList';
import { fetchTopPhysicians } from './services/gemini';
import { Physician } from './types';
import { AlertCircle } from 'lucide-react';

const App: React.FC = () => {
  const [currentCondition, setCurrentCondition] = useState<string>('');
  const [physicians, setPhysicians] = useState<Physician[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async (condition: string) => {
    setLoading(true);
    setError(null);
    setCurrentCondition(condition);
    setPhysicians([]); // Clear previous results

    try {
      const data = await fetchTopPhysicians(condition);
      setPhysicians(data.physicians || []);
    } catch (err) {
      setError("Failed to fetch physicians. Please try again later or check your connection.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      <Header />
      
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <div className="max-w-4xl mx-auto space-y-8">
            
            {/* Search Section */}
            <ConditionSearch onSearch={handleSearch} isLoading={loading} />

            {/* Error State */}
            {error && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start">
                    <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 mr-3 flex-shrink-0" />
                    <div>
                        <h3 className="text-sm font-medium text-red-800">Error Loading Data</h3>
                        <p className="text-sm text-red-700 mt-1">{error}</p>
                    </div>
                </div>
            )}

            {/* Loading Skeleton */}
            {loading && (
                <div className="space-y-4 animate-pulse">
                     <div className="h-8 bg-slate-200 rounded w-1/3 mb-6"></div>
                     {[1, 2, 3].map(i => (
                        <div key={i} className="bg-white p-6 rounded-2xl border border-slate-100 h-48 w-full"></div>
                     ))}
                </div>
            )}

            {/* Results Section */}
            {!loading && !error && physicians.length > 0 && (
                <PhysicianList physicians={physicians} condition={currentCondition} />
            )}

            {/* Empty State / Initial Instructions */}
            {!loading && !error && physicians.length === 0 && currentCondition && (
                <div className="text-center py-12">
                     <p className="text-slate-500">No results found for "{currentCondition}". Try a broader term.</p>
                </div>
            )}
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 mt-auto py-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-400 text-sm">
            <p>&copy; {new Date().getFullYear()} CanDoc Finder. All rights reserved.</p>
            <p className="mt-2 text-xs">
                Disclaimer: This is a demo application using AI-generated data. 
                Physician availability is simulated and does not reflect real-time schedules.
            </p>
        </div>
      </footer>
    </div>
  );
};

export default App;