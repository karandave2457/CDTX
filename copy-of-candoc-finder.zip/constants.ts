import { Condition } from './types';

export const COMMON_CONDITIONS: Condition[] = [
  { id: '1', name: 'Cardiology (Heart)', icon: 'Heart' },
  { id: '2', name: 'Dermatology (Skin)', icon: 'Sun' },
  { id: '3', name: 'Neurology (Brain)', icon: 'Brain' },
  { id: '4', name: 'Orthopedics (Bone/Joint)', icon: 'Bone' },
  { id: '5', name: 'Oncology (Cancer)', icon: 'Activity' },
  { id: '6', name: 'Pediatrics (Children)', icon: 'Baby' },
  { id: '7', name: 'Psychiatry (Mental Health)', icon: 'Smile' },
  { id: '8', name: 'Endocrinology (Hormones)', icon: 'Zap' },
];

export const PROVINCES = [
  'Ontario',
  'British Columbia',
  'Quebec',
  'Alberta',
  'Nova Scotia',
  'Manitoba',
  'Saskatchewan',
  'New Brunswick',
  'Newfoundland and Labrador',
  'Prince Edward Island'
];