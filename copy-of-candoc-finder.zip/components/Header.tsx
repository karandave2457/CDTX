import React from 'react';
import { Activity, ShieldCheck } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="bg-teal-600 p-2 rounded-lg">
            <Activity className="h-6 w-6 text-white" />
          </div>
          <span className="text-xl font-bold text-slate-800 tracking-tight">CanDoc<span className="text-teal-600">Finder</span></span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="hidden md:flex items-center text-sm text-slate-500">
            <ShieldCheck className="w-4 h-4 mr-1 text-teal-600" />
            Verified Specialists
          </span>
          <div className="h-8 w-8 rounded-full bg-slate-100 flex items-center justify-center text-teal-700 font-semibold text-sm">
            CA
          </div>
        </div>
      </div>
    </header>
  );
};