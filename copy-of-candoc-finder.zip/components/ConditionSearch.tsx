import React, { useState } from 'react';
import { Search, Loader2 } from 'lucide-react';
import { COMMON_CONDITIONS } from '../constants';

interface ConditionSearchProps {
  onSearch: (condition: string) => void;
  isLoading: boolean;
}

export const ConditionSearch: React.FC<ConditionSearchProps> = ({ onSearch, isLoading }) => {
  const [query, setQuery] = useState('');

  const handleCustomSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  return (
    <div className="w-full bg-white rounded-2xl shadow-sm border border-slate-200 p-6 md:p-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-2">Find a Specialist</h2>
      <p className="text-slate-500 mb-6">Select a condition below or search for a specific medical issue to find top-rated doctors in Canada.</p>
      
      {/* Search Input */}
      <form onSubmit={handleCustomSearch} className="relative mb-8">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="e.g. Migraine, Arthritis, Sleep Apnea..."
          className="w-full pl-12 pr-4 py-4 rounded-xl border border-slate-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all outline-none text-lg text-slate-800 placeholder:text-slate-400"
          disabled={isLoading}
        />
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 h-6 w-6" />
        <button 
          type="submit"
          disabled={isLoading || !query.trim()}
          className="absolute right-2 top-2 bottom-2 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 text-white px-6 rounded-lg font-medium transition-colors flex items-center"
        >
          {isLoading ? <Loader2 className="animate-spin h-5 w-5" /> : 'Find'}
        </button>
      </form>

      {/* Quick Select Tags */}
      <div>
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Common Conditions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {COMMON_CONDITIONS.map((cond) => (
            <button
              key={cond.id}
              onClick={() => {
                setQuery(cond.name);
                onSearch(cond.name);
              }}
              disabled={isLoading}
              className="flex items-center p-3 rounded-lg border border-slate-100 bg-slate-50 hover:bg-teal-50 hover:border-teal-200 transition-all text-left group disabled:opacity-50"
            >
              <div className="mr-3 p-2 bg-white rounded-md shadow-sm group-hover:shadow text-teal-600">
               {/* Simple Icon placeholder logic since we can't dynamically import easily without a map */}
               <div className="w-4 h-4 rounded-full bg-teal-100" />
              </div>
              <span className="text-sm font-medium text-slate-700 group-hover:text-teal-800">{cond.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};