import React from 'react';
import { Calendar, Clock, Check } from 'lucide-react';
import { AvailabilitySlot } from '../types';

interface AvailabilityCalendarProps {
  slots: AvailabilitySlot[];
  selectedSlot: { date: string; time: string } | null;
  bookedSlot?: { date: string; time: string } | null;
  onSelectSlot: (date: string, time: string) => void;
}

export const AvailabilityCalendar: React.FC<AvailabilityCalendarProps> = ({ slots, selectedSlot, bookedSlot, onSelectSlot }) => {
  // Sort slots by date
  const sortedSlots = [...slots].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  if (sortedSlots.length === 0) {
    return <div className="text-sm text-slate-500 italic">No specific availability data online. Call to book.</div>;
  }

  return (
    <div className="mt-4 bg-slate-50 rounded-xl p-4 border border-slate-100">
        <h4 className="flex items-center text-sm font-semibold text-slate-700 mb-3">
            <Calendar className="w-4 h-4 mr-2 text-teal-600" />
            Select an Appointment Time
        </h4>
        <div className="space-y-3">
            {sortedSlots.map((slot, idx) => {
                const dateObj = new Date(slot.date);
                const day = dateObj.getDate();
                const month = dateObj.toLocaleString('default', { month: 'short' });
                const weekday = dateObj.toLocaleString('default', { weekday: 'short' });

                return (
                    <div key={`${slot.date}-${idx}`} className="flex items-start bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
                        <div className="flex-shrink-0 w-14 text-center mr-4 border-r border-slate-100 pr-4">
                            <span className="block text-xs font-bold text-slate-400 uppercase">{month}</span>
                            <span className="block text-xl font-bold text-slate-800">{day}</span>
                            <span className="block text-xs text-slate-500">{weekday}</span>
                        </div>
                        <div className="flex-grow">
                             <div className="flex flex-wrap gap-2">
                                {slot.times.map((time, tIdx) => {
                                    const isSelected = selectedSlot?.date === slot.date && selectedSlot?.time === time;
                                    const isBooked = bookedSlot?.date === slot.date && bookedSlot?.time === time;

                                    let buttonClasses = "bg-teal-50 text-teal-700 border-teal-100 hover:bg-teal-100 hover:border-teal-200";
                                    
                                    if (isBooked) {
                                        buttonClasses = "bg-emerald-600 text-white border-emerald-600 shadow-md transform scale-105 ring-2 ring-emerald-100";
                                    } else if (isSelected) {
                                        buttonClasses = "bg-teal-600 text-white border-teal-600 shadow-md transform scale-105";
                                    }

                                    return (
                                        <button 
                                            key={tIdx} 
                                            onClick={() => !isBooked && onSelectSlot(slot.date, time)}
                                            className={`inline-flex items-center px-3 py-1.5 rounded-md text-xs font-medium border transition-all duration-300 ${buttonClasses}`}
                                        >
                                            {isBooked ? (
                                                <Check className="w-3 h-3 mr-1 animate-in zoom-in duration-300" />
                                            ) : (
                                                <Clock className={`w-3 h-3 mr-1 ${isSelected ? 'text-white' : ''}`} />
                                            )}
                                            {time}
                                        </button>
                                    );
                                })}
                             </div>
                        </div>
                    </div>
                );
            })}
        </div>
        <div className="mt-3 text-center">
             <button className="text-xs font-medium text-teal-600 hover:text-teal-800 transition-colors">
                View Full Calendar &rarr;
             </button>
        </div>
    </div>
  );
};