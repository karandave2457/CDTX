import React, { useState, useMemo } from 'react';
import { MapPin, Star, Phone, Mail, Award, ChevronDown, ChevronUp, ExternalLink, CheckCircle } from 'lucide-react';
import { Physician } from '../types';
import { AvailabilityCalendar } from './AvailabilityCalendar';

interface PhysicianCardProps {
  physician: Physician;
}

export const PhysicianCard: React.FC<PhysicianCardProps> = ({ physician }) => {
  const [expanded, setExpanded] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<{ date: string; time: string } | null>(null);
  const [isBooked, setIsBooked] = useState(false);

  // Sort availability to ensure we find the true earliest date
  const sortedAvailability = useMemo(() => {
    if (!physician.availability) return [];
    return [...physician.availability].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
  }, [physician.availability]);

  const nextAvailableDate = sortedAvailability.length > 0 ? sortedAvailability[0].date : 'Contact Clinic';

  const handleBookAppointment = () => {
      if (!selectedSlot) return;
      
      let url = physician.bookingUrl;
      
      if (!url) {
          // Fallback if no URL is present
          console.warn("No booking URL provided for this physician.");
          return;
      }

      // Ensure URL has protocol
      if (!url.startsWith('http')) {
          url = `https://${url}`;
      }
      
      // Append query params for date and time to simulate a deep link to that specific slot
      const separator = url.includes('?') ? '&' : '?';
      const params = new URLSearchParams({
          date: selectedSlot.date,
          time: selectedSlot.time,
          ref: 'candoc-finder'
      });
      
      const finalUrl = `${url}${separator}${params.toString()}`;
      
      // Visual Feedback Sequence
      setIsBooked(true);
      window.open(finalUrl, '_blank', 'noopener,noreferrer');

      // Reset after delay
      setTimeout(() => {
        setIsBooked(false);
        setSelectedSlot(null); // Clear selection to indicate completion
      }, 2500);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow duration-300">
      <div className="p-6">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Avatar / Initials */}
          <div className="flex-shrink-0">
            <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-slate-100 flex items-center justify-center border-4 border-white shadow-sm ring-1 ring-slate-100 overflow-hidden relative">
               <img 
                 src={`https://picsum.photos/seed/${physician.id}/200/200`} 
                 alt={physician.name}
                 className="w-full h-full object-cover opacity-90"
               />
            </div>
          </div>

          {/* Main Info */}
          <div className="flex-grow">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-bold text-slate-900">{physician.name}</h3>
                <p className="text-teal-600 font-medium">{physician.specialty}</p>
              </div>
              <div className="flex items-center bg-amber-50 px-2 py-1 rounded-full border border-amber-100">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500 mr-1" />
                <span className="text-sm font-bold text-amber-700">{physician.rating}</span>
              </div>
            </div>

            <div className="flex items-center mt-2 text-slate-500 text-sm">
                <MapPin className="w-4 h-4 mr-1.5 flex-shrink-0" />
                <span>{physician.clinicName} • {physician.city}, {physician.province}</span>
            </div>

            <div className="mt-4 flex flex-wrap gap-4 text-sm">
                {physician.yearsExperience > 0 && (
                     <div className="flex items-center text-slate-600">
                        <Award className="w-4 h-4 mr-2 text-indigo-500" />
                        {physician.yearsExperience} Years Exp.
                    </div>
                )}
                <div className="flex items-center text-slate-600">
                    <Phone className="w-4 h-4 mr-2 text-emerald-500" />
                    {physician.phone}
                </div>
            </div>
            
            <p className="mt-4 text-sm text-slate-600 line-clamp-2 md:line-clamp-none">
                {physician.bio}
            </p>
          </div>
        </div>
      </div>

      {/* Action / Availability Footer */}
      <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4">
         <div className="text-xs text-slate-500 font-medium">
            Next Available: <span className="text-slate-900 font-semibold">{nextAvailableDate}</span>
         </div>
         <button 
            onClick={() => setExpanded(!expanded)}
            className="w-full md:w-auto flex items-center justify-center px-4 py-2 text-sm font-medium text-teal-700 bg-teal-50 hover:bg-teal-100 rounded-lg transition-colors"
         >
            {expanded ? 'Hide Schedule' : 'Check Availability'}
            {expanded ? <ChevronUp className="ml-2 w-4 h-4" /> : <ChevronDown className="ml-2 w-4 h-4" />}
         </button>
      </div>

      {/* Expanded Content */}
      {expanded && (
        <div className="p-6 bg-white border-t border-slate-100 animate-in slide-in-from-top-2 duration-200">
            {/* Pass sorted availability to calendar to ensure consistent ordering */}
            <AvailabilityCalendar 
                slots={sortedAvailability} 
                selectedSlot={selectedSlot}
                bookedSlot={isBooked ? selectedSlot : null}
                onSelectSlot={(date, time) => !isBooked && setSelectedSlot({ date, time })}
            />
            <div className="mt-4 flex flex-col items-end">
                 <div className="flex items-center gap-4">
                     {isBooked && (
                        <span className="text-sm font-medium text-emerald-600 flex items-center animate-in fade-in slide-in-from-right-4 duration-300">
                            <CheckCircle className="w-4 h-4 mr-1.5" />
                            Booking initiated!
                        </span>
                     )}
                     <button 
                        onClick={handleBookAppointment}
                        disabled={!selectedSlot || isBooked}
                        className={`
                            font-medium py-2 px-6 rounded-lg shadow-sm transition-all flex items-center duration-300
                            ${selectedSlot && !isBooked
                                ? 'bg-teal-600 hover:bg-teal-700 text-white transform active:scale-95' 
                                : isBooked
                                    ? 'bg-emerald-100 text-emerald-700 cursor-default'
                                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                            }
                        `}
                     >
                        {isBooked ? 'Redirecting...' : 'Book Appointment'}
                        {selectedSlot && !isBooked && <ExternalLink className="ml-2 w-4 h-4" />}
                     </button>
                 </div>
                 {!selectedSlot && !isBooked && (
                    <p className="text-xs text-right text-slate-400 mt-2">Please select a time slot above to proceed.</p>
                 )}
            </div>
        </div>
      )}
    </div>
  );
};