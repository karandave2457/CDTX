import React, { useState, useMemo } from 'react';
import { Physician } from '../types';
import { PhysicianCard } from './PhysicianCard';
import { PROVINCES } from '../constants';

interface PhysicianListProps {
  physicians: Physician[];
  condition: string;
}

export const PhysicianList: React.FC<PhysicianListProps> = ({ physicians, condition }) => {
  const [selectedProvince, setSelectedProvince] = useState<string>('All');
  const [sortBy, setSortBy] = useState<string>('Recommended');

  const filteredAndSortedPhysicians = useMemo(() => {
    // 1. Filter by Province
    let result = selectedProvince === 'All' 
      ? [...physicians] 
      : physicians.filter(p => p.province === selectedProvince);

    // 2. Sort results
    switch (sortBy) {
      case 'Highest Rated':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'Earliest Availability':
        result.sort((a, b) => {
          // Helper to get timestamp of first slot
          const getEarliestTime = (p: Physician) => {
             if (!p.availability || p.availability.length === 0) return Number.MAX_VALUE;
             // Sort slots dates to be safe and pick the first one
             const dates = p.availability.map(s => new Date(s.date).getTime());
             return Math.min(...dates);
          };
          return getEarliestTime(a) - getEarliestTime(b);
        });
        break;
      case 'Recommended':
      default:
        // Keep original order from API
        break;
    }

    return result;
  }, [physicians, selectedProvince, sortBy]);

  if (physicians.length === 0) return null;

  return (
    <div className="w-full mt-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 gap-4">
        <div>
            <h2 className="text-2xl font-bold text-slate-900">Top Physicians for "{condition}"</h2>
            <p className="text-slate-500">
                Found {filteredAndSortedPhysicians.length} specialists 
                {selectedProvince !== 'All' ? ` in ${selectedProvince}` : ' in Canada'}
            </p>
        </div>
        
        <div className="flex gap-3 w-full md:w-auto">
             {/* Province Filter */}
             <div className="relative w-full md:w-auto">
                <label className="block md:hidden text-xs font-semibold text-slate-500 mb-1">Filter by Province</label>
                <select 
                    value={selectedProvince}
                    onChange={(e) => setSelectedProvince(e.target.value)}
                    className="w-full md:w-48 bg-white border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-teal-500 focus:border-teal-500 block p-2.5 outline-none cursor-pointer"
                >
                    <option value="All">All Provinces</option>
                    {PROVINCES.map(province => (
                        <option key={province} value={province}>{province}</option>
                    ))}
                </select>
             </div>

            {/* Sort Dropdown */}
            <div className="hidden md:block">
                <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="bg-white border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-teal-500 focus:border-teal-500 p-2.5 outline-none cursor-pointer"
                >
                    <option value="Recommended">Recommended</option>
                    <option value="Highest Rated">Highest Rated</option>
                    <option value="Earliest Availability">Earliest Availability</option>
                </select>
            </div>
        </div>
      </div>
      
      <div className="grid gap-6">
        {filteredAndSortedPhysicians.length > 0 ? (
            filteredAndSortedPhysicians.map((physician, idx) => (
              <PhysicianCard key={physician.id || idx} physician={physician} />
            ))
        ) : (
            <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300">
                <p className="text-slate-500 text-lg">No physicians found in <span className="font-semibold">{selectedProvince}</span> for this condition.</p>
                <button 
                    onClick={() => setSelectedProvince('All')}
                    className="mt-4 px-4 py-2 bg-teal-50 text-teal-700 rounded-lg font-medium hover:bg-teal-100 transition-colors"
                >
                    View all provinces
                </button>
            </div>
        )}
      </div>
    </div>
  );
};